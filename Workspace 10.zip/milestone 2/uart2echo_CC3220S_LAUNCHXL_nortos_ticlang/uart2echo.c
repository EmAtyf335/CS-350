#include <stdint.h>
#include <stddef.h>

/* Driver Header files */
#include <ti/drivers/GPIO.h>
#include <ti/drivers/UART2.h>

/* Driver configuration */
#include "ti_drivers_config.h"

/* State Machine states */
typedef enum {
    STATE_INIT,
    STATE_IDLE,
    STATE_LED_ON,
    STATE_LED_OFF
} State;

/* State Machine Variables */
State currentState = STATE_INIT;
char input;

/* UART Variables */
UART2_Handle uart;
UART2_Params uartParams;
size_t bytesRead;
size_t bytesWritten = 0;
uint32_t status = UART2_STATUS_SUCCESS;

/* Function prototypes */
void turnOnLED();
void turnOffLED();

/*
* ======== mainThread ========
*/
void *mainThread(void *arg0)
{
    const char echoPrompt[] = "Echoing characters:\r\n";

    /* Call driver init functions */
    GPIO_init();

    /* Configure the LED pin */
    GPIO_setConfig(CONFIG_GPIO_LED_0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);

    /* Create a UART where the default read and write mode is BLOCKING */
    UART2_Params_init(&uartParams);
    uartParams.baudRate = 115200;

    uart = UART2_open(CONFIG_UART2_0, &uartParams);

    if (uart == NULL) {
        /* UART2_open() failed */
        while (1);
    }

    /* Turn on user LED to indicate successful initialization */
    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);

    UART2_write(uart, echoPrompt, sizeof(echoPrompt), &bytesWritten);

    /* State Machine Loop */
    while (1) {
        switch (currentState) {
            case STATE_INIT:
                currentState = STATE_IDLE;
                break;

            case STATE_IDLE:
                bytesRead = 0;
                status = UART2_read(uart, &input, 1, &bytesRead);
                if (status == UART2_STATUS_SUCCESS && bytesRead > 0) {
                    if (input == '1') {
                        currentState = STATE_LED_ON;
                    } else if (input == '0') {
                        currentState = STATE_LED_OFF;
                    }
                }
                break;

            case STATE_LED_ON:
                turnOnLED();
                currentState = STATE_IDLE;
                break;

            case STATE_LED_OFF:
                turnOffLED();
                currentState = STATE_IDLE;
                break;

            default:
                currentState = STATE_INIT;
                break;
        }
    }
}

/* Function to turn on LED */
void turnOnLED() {
    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);
}

/* Function to turn off LED */
void turnOffLED() {
    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
}
