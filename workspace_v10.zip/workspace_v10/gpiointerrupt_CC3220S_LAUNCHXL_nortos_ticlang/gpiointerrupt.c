#include <stdint.h>
#include <stddef.h>

/* Driver Header files */
#include <ti/drivers/GPIO.h>

/* Driver configuration */
#include "ti_drivers_config.h"
#include <ti/drivers/Timer.h>

// Morse code sequences for SOS and OK
const int s[] = {0, 3, 3, 3, 0};
const int o[] = {0, 3, 3, 3, 0, 3, 3, 3, 0};
const int k[] = {3, 3, 3, 0, 3, 3, 3, 0};

// Message to be displayed
int *message = s;
int message_length = sizeof(s) / sizeof(int);

// Keep track of the current position in the message
int message_position = 0;

// Keep track of whether the button has been pressed
int button_pressed = 0;

void timerCallback(Timer_Handle myHandle, int_fast16_t status)
{
    // Toggle the LEDs based on the current position in the message
    GPIO_write(CONFIG_GPIO_LED_0, message[message_position] != 0);
    GPIO_write(CONFIG_GPIO_LED_1, message[message_position] == 2 || message[message_position] == 3);

    // Move to the next position in the message
    message_position++;
    if (message_position == message_length) {
        message_position = 0;

        // Toggle the message if the button has been pressed
        if (button_pressed) {
            if (message == s) {
                message = k;
                message_length = sizeof(k) / sizeof(int);
            } else {
                message = s;
                message_length = sizeof(s) / sizeof(int);
            }
        }
    }
}

void initTimer(void)
{
    Timer_Handle timer0;
    Timer_Params params;

    Timer_init();

    Timer_Params_init(&params);
    params.period = 500000;
    params.periodUnits = Timer_PERIOD_US;
    params.timerMode = Timer_CONTINUOUS_CALLBACK;
    params.timerCallback = timerCallback;

    timer0 = Timer_open(CONFIG_TIMER_0, &params);
    if (timer0 == NULL) {
        /* Failed to initialized timer */
        while (1) {}
    }

    if (Timer_start(timer0) == Timer_STATUS_ERROR) {
        /* Failed to start timer */
        while (1) {}
    }
}

/*
* ======== gpioButtonFxn0 ========
* Callback function for the GPIO interrupt on CONFIG_GPIO_BUTTON_0.
*
* Note: GPIO interrupts are cleared prior to invoking callbacks.
*/
void gpioButtonFxn0(uint_least8_t index)
{
    button_pressed = 1;
}

/*
* ======== mainThread ========
*/
void *mainThread(void *arg0)
{
    /* Call driver init functions */
    GPIO_init();

    /* Configure the LED and button pins */
    GPIO_setConfig(CONFIG_GPIO_LED_0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(CONFIG_GPIO_LED_1, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(CONFIG_GPIO_BUTTON_0, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);

    /* Turn on user LED */
    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);

    /* Install Button callback */
    GPIO_setCallback(CONFIG_GPIO_BUTTON_0, gpioButtonFxn0);

    /* Enable interrupts */
    GPIO_enableInt(CONFIG_GPIO_BUTTON_0);

    /* Initialize the timer */
    initTimer();

    return (NULL);
}
